================================================================================
Wage's Perks  v1.4.4   (Probably Stolen)
================================================================================

A large content mod for Probably Stolen: 22 starting perks, two recurring
characters (Wage Brother / Wage Girl), container and machine upgrades, and a
story layer.

Probably Stolen 的大型内容 mod：22 个起始特性、蛙哥/蛙娘两个常驻角色、
容器与机器升级、以及一层剧情内容。

--------------------------------------------------------------------------------
SUPPORT / 支持与交流（重要，先看这里）
--------------------------------------------------------------------------------
* 爱发电赞助：https://afdian.com/a/wagesperks
* QQ 交流群：1109707341（报 bug、提建议、领前瞻版都在这）
* Afdian: https://afdian.com/a/wagesperks   QQ group: 1109707341

--------------------------------------------------------------------------------
CONFIG QUICK START / 配置快速上手（三选一，任一都行）
--------------------------------------------------------------------------------
1) 游戏内改：打开 Mods 菜单 -> Wage's Perks -> Settings（主菜单另有
   「WP 配置」按钮，14 页 218 项，中英双语随游戏语言自动切换）。
   In game: Mods menu -> Wage's Perks -> Settings, or the "WP Config"
   button on the main menu (14 pages, 218 options).

2) 手动改配置文件（推荐熟悉文本编辑器的玩家）：
   路径：%USERPROFILE%\AppData\LocalLow\<Company>\Probably Stolen\
        ModConfigs\wage_perks.json
   完整中英对照清单见压缩包内 配置教程_ConfigGuide.txt。
   Manual edit: open the wage_perks.json above and change any value.

3) 改了不生效？先删配置文件让它重新生成，再进游戏：
   关游戏 -> 删除 ModConfigs\wage_perks.json -> 开游戏（会自动按默认值
   重建）-> 再改。多数「改了没反应」都是改错文件/改错键/文件缓存所致，
   删除重建是标准解法。
   Changes not taking effect? Close the game, delete
   ModConfigs\wage_perks.json, relaunch (it regenerates with defaults),
   then edit again.

--------------------------------------------------------------------------------
WHAT'S NEW IN 1.4.4
本次更新
--------------------------------------------------------------------------------
* Dice of Fate saves, the big one: the dice was never registered into the item
  directory, so after a reload it came back as a nameless 1x1 blank with an
  "unknown" icon - and saving again deleted it from your bag for good. It is now
  registered properly, old saves are repaired in place, and a save that already
  lost the dice gets one back.
  命运骰子存档（本条最要命）：骰子一直没注册进物品目录，读档后会变成名字空白、
  图标 unknown 的 1×1 空壳，再存一次档就彻底从背包消失。现已正确注册，老档
  就地修复，已经丢了骰子的存档会补发一个。

* Wonder Box no longer drops back to a 3x3 box after reload. Four separate holes
  were plugged: the stage was only keyed by grid position (a box put into a bag
  lost its stage entirely), position keys could override the real stage, 3x3 was
  always read as stage 0, and the reload pass never looked inside bags, void beads
  or dice. This also fixes "everything in the Wage Brother's storage vanished
  after reload".
  妙妙箱读档不再退回 3×3。四处断链全补：段位原来只按格子位置记（箱子一进背包
  就断链）、位置键会覆盖真实段位、3×3 一律判 0 级、读档遍历不进背包/虚空珠/骰子
  内部。顺带修好「蛙哥仓库读档后东西全不见」——那正是箱子退回 3×3 后物品落在
  网格外。

* Wage Girl's affection and six stats no longer reset to zero when you quit and
  come back. "Close up shop, then quit" is the normal way to end a day, and that
  path flushed the save before her stats were ever pushed into it.
  蛙娘好感与六维退出重进不再清零。「打烊→退出」是正常玩法，而这条路径在蛙娘
  数据推进存储层之前就把档写了，写进去的是 0 项。

* Void Bead container no longer renders as one blank colour block. Locked slots
  and unlocked slots are now visually distinct, so you can actually see how many
  slots you have and which ones are still sealed.
  虚空珠容器不再是一整块纯色空板：锁定格与已解锁格现在肉眼可分，能看出真实
  容量上限，不再出现「物品全挤在第一行、下面看着像空地」的错觉。

* Void Bead skin switching. Right-click the bead and use the "Toggle" button to
  cycle its appearance - the default deep-violet bead or the new dark black-gold
  one. Your choice is stored on the item itself, so it survives reloading and
  still works when the bead is tucked inside a backpack, the Wonder Box or the
  dice. Left-click still opens the container as before.
  虚空珠皮肤切换：右键虚空珠，点「切换」按钮即可在「原版深紫虚空珠」与「黑金
  虚空珠」两套外观之间循环。选择记在物品自己身上，读档不丢；虚空珠被塞进背包、
  妙妙箱或骰子内部时同样有效。左键仍然是打开容器，行为不变。

* Dice of Fate conversion now grows. Every successful conversion adds permanent
  growth and the product's value scales with it (up to +50% at level 25, no cap
  on the counter itself). The item name shows the level and bonus.
  命运骰子炼化成长：每次成功炼化永久累积成长，产物价值随之提升（25 级封顶
  +50%），物品名会显示等级与加成。成长与「暴击累积」是两条独立曲线，后者出
  好物即归零，前者不回收。

* Offering space in the Altar of Fate is now 6x9 (was 4x3), the same size as the
  standard supply crates. Old dice are grown in place, never shrunk, so nothing
  gets swallowed.
  命运祭坛祭品空间 4×3 → 6×9，对齐标准物资箱尺寸。老档骰子原地扩容，只扩不缩，
  不会吞物品。

* Wage Brother's budget is no longer clamped to nothing. The upper bound meant for
  customers was also hitting him, squashing an 11-digit budget down to 10 million.
  蛙哥预算不再被压成 0：给顾客用的上限误伤到蛙哥，11 位数预算被压到 1000 万。

* Infamous + Deficit is playable again - for real this time. The security
  department now has a reputation floor (default -99, set it to 0 to turn the
  floor off), so a -99 rating can't sit one point away from the -100 lockout.
  The floor allows the rating to climb, it only stops it from sinking further.
  声名狼藉 + 赤字连连组合恢复可玩（这次是真修好了）：治安部声望加了地板，默认
  -99，配置里改成 0 可关闭。地板只拦「继续往下掉」，声望还是可以往上涨，所以
  -99 依旧人嫌狗厌、但不会差 1 点就撞上 -100 的「立即逮捕」区间。

* Fixed a whole class of settings that were silently doing nothing. Three
  separate bugs were stacked on top of each other: the security floor patch was
  attached to the wrong overload (so it never ran), 32 settings were defined but
  missing from the settings menu (so you could not even change them), and the
  self-check that was supposed to catch the second problem had never printed a
  single line. All three are fixed, and the menu now covers all 218 settings.
  修掉一整类「改了没反应」的配置。三个问题叠在一起：治安部地板补丁挂错了重载
  （所以从来没跑过）；32 项配置定义了却不在设置菜单里（所以根本改不到）；本该
  发现第二件事的自检从上线起就没输出过一行。三个都修了，菜单现在覆盖全部 218 项。

* Settings that genuinely do nothing are now labelled. 38 options are marked
  "Inactive" in the menu with the reason, so you stop wondering whether you set
  them wrong. Most of them moved to the Wage Survival module.
  确实不生效的配置现在会标出来：38 项在菜单里带「⚠ 不生效」标记并写明原因，
  不用再猜是不是自己没设对。其中大部分功能已移交给 Wage Survival 模块。

* Name cards can go into the dossier cabinet now (they used to be rejected by a
  pure tag whitelist).
  名片现在可以放进档案柜（原来被纯 tag 白名单挡掉）。

* Empty containers dropped onto the dice are absorbed instead of eating a slot in
  the offering space.
  空箱子拖到骰子上改为直接吸收，不再白占祭品空间。

* New option WageBrotherEnabled: turn the Wage Brother off if you only want the
  starting perks.
  新增开关 WageBrotherEnabled：只要开局天赋、不要蛙哥的可以关掉。

* The Void Bead's debug spam is gone (it was filling up some players' logs).
  虚空珠的调试日志刷屏已撤掉（之前有玩家的日志被刷满）。

* Faster startup: the 242-line patch registration dump and the overload-ambiguity
  diagnostics now only run in debug mode.
  启动更快：242 条补丁注册清单与重载歧义诊断改为只在调试模式下跑。

* Prepared for the game's December 10 scanner rule: all reflection into engine and
  system internals is gone, and the manifest now declares only `files`.
  为游戏 12 月 10 日的扫描新规做好准备：对引擎/系统内部的反射已全部清零，
  manifest 只声明 files。届时扫描器硬拒绝也照常加载。

* Also fixed while in there: two perks that silently did nothing because they
  looked up IL2CPP-era field names that don't exist in the Mono build - the
  Wage Brother's stock-tag category scan and the smart-buy category filter now
  actually work.
  顺带修好两个「一直在空转」的特性：蛙哥点货签的品类扫描、智能买货的品类过滤
  原来反射找的是 IL2CPP 时代的字段名，Mono 正式版里根本不存在，所以永远返回空。
--------------------------------------------------------------------------------
INSTALL / 安装
--------------------------------------------------------------------------------
1. Close the game. 先关游戏。

2. DELETE the old single-file install if you have one:
   如果你装过旧版（单文件），先删掉：
       Mods\WagePerks.dll
       Mods\WagesPerks.dll
       Mods\story_content.json      (old location / 旧位置)
   Leaving them in place can load the mod twice. 留着可能双加载。

3. Copy the whole "Mods" folder from this archive into your game folder,
   merging with the existing Mods folder. Result:
   把压缩包里的 Mods 文件夹整体覆盖到游戏目录，合并后应是这样：

       <Game>\Mods\wage_perks\manifest.xml
       <Game>\Mods\wage_perks\WagePerks.dll
       <Game>\Mods\wage_perks\story_content.json
       <Game>\Mods\wage_perks\Textures\Items\*.png

4. Launch the game, open the Mods menu, and ENABLE "Wage's Perks".
   The game does not auto-enable newly installed mods.
   启动游戏 -> 打开 Mods 菜单 -> 手动启用 Wage's Perks。
   游戏不会自动启用新装的 mod，这步不做等于没装。

5. Start a new run (or load a save). Perks appear on the starting-perk screen.
   开新档或读档，起始特性界面即可选到。

--------------------------------------------------------------------------------
REQUIREMENTS / 前置
--------------------------------------------------------------------------------
* Probably Stolen, game version 0.46.x
* No other mods required. Wage Survival and Black Gold Box are optional
  companions and work standalone.
* 无前置。Wage Survival / 黑金典藏箱 是可选搭配，可单独使用。

--------------------------------------------------------------------------------
NOTES / 说明
--------------------------------------------------------------------------------
* Story content is test material and is OFF by default.
  Enable it under "U Story" in the config if you want to try it.
  剧情内容是测试内容，默认关闭。想试的话在配置的「U 剧情」里打开。

* The mod writes its save data to Mods\WagesPerks\ (capital W). Do not delete
  that folder - it holds your mod progress, not mod files.
  mod 存档写在 Mods\WagesPerks\（大写 W），那是存档数据不是 mod 文件，别删。

* Bug reports: please attach Player.log and, if possible, the ModConfigs JSON.
  反馈问题请附 Player.log，最好再带上 ModConfigs 里的 json。

--------------------------------------------------------------------------------
LINKS / 链接
--------------------------------------------------------------------------------
QQ group / QQ群 : 1109707341
Afdian / 爱发电 : https://afdian.com/a/wagesperks
GitHub          : https://github.com/gwxxwg12332-bot/wageperks

================================================================================
